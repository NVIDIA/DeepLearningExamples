#!/bin/bash

docker build . --rm -t bert
